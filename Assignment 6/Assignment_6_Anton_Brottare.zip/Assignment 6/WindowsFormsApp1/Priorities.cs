﻿// Anton Brottare 2018-01-03

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    enum Priorities
    {
        Not_important,
        Low,
        Medium,
        High,
        Very_important
    }
}
