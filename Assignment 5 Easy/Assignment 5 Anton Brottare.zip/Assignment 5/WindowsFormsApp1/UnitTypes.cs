﻿//Anton Brottare 28/11-2017
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    enum UnitTypes
    {
       cm,
       ft,
       g,
       gallon,
       inch,
       kg,
       lb,
       lit,
       m,
       oz,
       piece
    }
}
